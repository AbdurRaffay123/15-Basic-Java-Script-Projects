const api_url = "https://api.quotable.io/random";
const QUOTE = document.querySelector('.quote');
const AUTHOR =document.querySelector(".author_name"); 


async function getQuote(api_url){
    const response = await fetch(api_url);
    let data = await response.json();
    console.log(data);

    QUOTE.innerHTML = data.content;
    AUTHOR.innerHTML = data.author;
}

getQuote(api_url);

function tweet(){
    window.open("https://twitter.com/intent/tweet?text="+QUOTE.innerHTML + "    ~by " + AUTHOR.innerHTML,"Tweet Window","width=600 , height=300");
}