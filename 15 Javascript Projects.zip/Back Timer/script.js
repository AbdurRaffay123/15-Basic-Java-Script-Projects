let Timeline = new Date("nov 30 2023 01:00:00").getTime();

let days=document.getElementById("days");
let hours=document.getElementById("hours");
let mins=document.getElementById("mins");
let seconds=document.getElementById("seconds");

const timer=()=> {
  let now = new Date().getTime();

  let distance = Timeline - now;

  var Days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var Hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var Minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var sec = Math.floor((distance % (1000 * 60)) / 1000);

  if(Hours>12)
  {
    Hours=Hours-12;
  }
  Days = Days<10? "0"+ Days : Days;
  Hours = Hours<10? "0"+ Hours : Hours;
  Minutes = Minutes<10? "0" + Minutes : Minutes;
  sec = sec<10? "0" + sec : sec;

      days .innerHTML =  Days;  
      hours.innerHTML= Hours;
      mins.innerHTML= Minutes;
      seconds.innerHTML=sec;

//When the Time will over:-
      if(distance<0)
      {
        clearInterval(x);
        days.innerHTML="00";
        hours.innerHTML="00";
        mins.innerHTML="00";
        seconds.innerHTML="00";
      }
    }

setInterval(timer,1000)