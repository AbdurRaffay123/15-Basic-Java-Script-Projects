const scrollContainer=document.querySelector(".gallery");
const nextButton=document.querySelector(".nextBtn");
const backButton=document.querySelector(".backBtn");

scrollContainer.addEventListener("wheel", (evt)=>{
    evt.preventDefault();
    scrollContainer.scrollLeft += evt.deltaY;
    scrollContainer.style.scrollBehavior = "auto";
});

nextButton.addEventListener("click", ()=>{
    scrollContainer.style.scrollBehavior ="smooth";
    scrollContainer.scrollLeft +=300;
});

backButton.addEventListener("click", ()=>{
    scrollContainer.style.scrollBehavior ="smooth";
    scrollContainer.scrollLeft -=300;
});