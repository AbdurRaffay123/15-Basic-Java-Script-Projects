function sendEmail(){
    Email.send({
        Host : "smtp.gmail.com",
        Username : "kraffay96@gmail.com",
        Password : "1donHEXAHGON",
        To : 'kibrahim2780@gmail.com',
        From : document.getElementById('mailBox').value,
        Subject : "Contact Form Information",
        Body : "And this is the body"
    }).then(
      message => alert(message)
    );
}

  // const scriptURL = 'https://script.google.com/macros/s/AKfycbw76JMFngxVDvb9LkEjzcF6X0hk_Bffn6bBBL5KNXKHR1gO3_OeQ9poVE7O95H8o1Xx/exec'
  // const form = document.forms['submit-to-google-sheet']

  // form.addEventListener('submit', e => {
  //   e.preventDefault()
  //   fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  //     .then(response => console.log('Success!', response))
  //     .catch(error => console.error('Error!', error.message))
  // })