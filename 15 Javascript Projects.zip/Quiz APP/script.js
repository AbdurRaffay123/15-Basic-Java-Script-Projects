const questions = [
    {
        question: "Who is the Final Messanger of Allah?",

        answers: [
            {text:"Muhammad SAW" ,correct: true},
            {text:"Ibrahim AS" ,correct: false},
            {text:"Musa AS" ,correct: false},
            {text:"Issa AS" ,correct: false},
        ]
    },
    {
        question: "What is the Name of Last revelation?",

        answers: [
            {text:"Torah" ,correct: false},
            {text:"Quran" ,correct: true},
            {text:"Bible" ,correct: false},
            {text:"Zabūr" ,correct: false},
        ]
    },
    {
        question: "Muhammad SAW died at the age of?",

        answers: [
            {text:"58" ,correct: false},
            {text:"64" ,correct: false},
            {text:"71" ,correct: false},
            {text:"63" ,correct: true},
        ]
    },
    {
        question: "How many prayers are there in one day?",

        answers: [
            {text:"50" ,correct: false},
            {text:"3" ,correct: false},
            {text:"5" ,correct: true},
            {text:"0" ,correct: false},
        ]
    },
    {
        question: "How many battle Fought by Muhammad SAW?",

        answers: [
            {text:"27" ,correct: true},
            {text:"32" ,correct: false},
            {text:"19" ,correct: false},
            {text:"8" ,correct: false},
        ]
    }
]

const Onquestion = document.getElementById("question");
const answer_buttons = document.getElementById("ans-btn");
const Next_btn = document.querySelector(".next-btn")
const removing_button =document.querySelector(".btn");

let currentIndex=0;
let score =0;

function startQuiz()
{
    Index=0;
    score=0;
    Next_btn.innerHTML="Next";
    showQuestion();
}

function showQuestion()
{
    resetState();
    let CurrentQuestion= questions[Index];
    let question_No = Index + 1; 
    Onquestion.innerHTML= question_No+ ". " + CurrentQuestion.question;

    CurrentQuestion.answers.forEach(answer=>{
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answer_buttons.appendChild(button);
        if(answer.correct){
            button.dataset.correct= answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    })
}

function resetState()
{
    Next_btn.style.display= 'none';
    while(answer_buttons.firstChild){
        answer_buttons.removeChild(answer_buttons.firstChild);
    }
}

function selectAnswer(e)
{
    let SelectedBtn = e.target;
    let IsCorrect = SelectedBtn.dataset.correct==="true";
    if(IsCorrect){
        SelectedBtn.classList.add("Correct");
        score++;
    }else{
        SelectedBtn.classList.add("incorrect");
    }
    Array.from(answer_buttons.children).forEach(button=>{
        if(button.dataset.correct === "true"){
            button.classList.add("Correct");
        }
        button.disabled= true;
    });
    Next_btn.style.display="block";
}

Next_btn.addEventListener("click",()=>{
        if(Index < questions.length){
            HandNextBtn();
        }else{
            startQuiz();
        }
})

function HandNextBtn(){
    Index++;
    if(Index < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}

function showScore(){
    resetState();
    Onquestion.innerHTML=`You scored ${score} out of ${questions.length} `;
    Next_btn.innerHTML= "Play Again";
    Next_btn.style.display = 'block';
}

startQuiz();