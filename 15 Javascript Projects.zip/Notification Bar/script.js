let toast_box= document.getElementById("toast-box");

// Got these link from FONT-AWESOME Wesbite:

let ScuccessMsg= `<i class="fa-solid fa-circle-check fa-shake"></i> Successfully Submitted `;
let errorMsg= `<i class="fa-solid fa-circle-xmark fa-shake"></i> Please fix the error `;
let invalidMsg= `<i class="fa-solid fa-circle-exclamation fa-shake"></i> Invalid input, Check again `;


function NotificationAlert(msg){
    let Toast= document.createElement('div');       // Created a div Element.
    Toast.classList.add('Toast-box-inner');         // Class given to a div element.
    Toast.innerHTML= msg;                           // Put the message into the div Element.
    toast_box.appendChild(Toast);                   // Added the div named ( Toast ) into div named ( toast_box ).

    if(msg.includes('error')){
        Toast.classList.add('error-inner');         // 1 class of ( error-inner ) will be added  if the user press Error Button.
    }

    if(msg.includes('Invalid')){
        Toast.classList.add('invalid-inner')        // 1 class of ( invalid-inner ) will be added if the user press Invalid Button. 
    }
    
    setTimeout(()=>{
        Toast.remove();                 //The div ( Toast ) will be removed after 6 second on the screen.
    },6000)
}