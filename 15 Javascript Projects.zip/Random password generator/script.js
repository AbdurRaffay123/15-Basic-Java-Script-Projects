const passCodeBox = document.getElementById("password");
const copied = document.querySelector('.copy');
let length_pass = 12;

let UpperCase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
let LowerCase = "abcdefghijklmnopqrstuvwxyz";
let symbols = "[!@#$%-^&*,/~)_+}:?>({<|;.]";
let numbers = "0123456789";
const All_Types = UpperCase + LowerCase + symbols + numbers;


function GeneratePass(){
    copied.style.display="none";
    let password = "";

//Here we are doing only for 4 characters only, then we execute while:

    // password+= UpperCase[Math.floor(Math.random() * UpperCase.length)]
    // password+= LowerCase[Math.floor(Math.random() * LowerCase.length)]
    // password+= numbers[Math.floor(Math.random() * numbers.length)]
    // password+= symbols[Math.floor(Math.random() * symbols.length)]

    while(length_pass > password.length){
        password+= All_Types[Math.floor(Math.random() * All_Types.length)]
    }
    passCodeBox.value= password;
}

function CopyPassword(){
    passCodeBox.select()
    document.execCommand("copy");

    copied.style.display="block";
}