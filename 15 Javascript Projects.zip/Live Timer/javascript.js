const updateTime=()=>{

    let DateTime=new Date();
    let hrs=DateTime.getHours();
    let mins=DateTime.getMinutes();
    let sec=DateTime.getSeconds();

    //For adding '0' if number is hrs, mins, seconds are smaller than 10;

        let space=document.getElementById('time_space');

    //Convertion of AM & PM

   if(hrs>=12){
    time_space.innerHTML='PM';
    //document.getElementById('time_space').innerHTML='PM';
   } 
   else{
    time_space.innerHTML='AM';
    //document.getElementById('time_space').innerHTML='AM';
   }

   if(hrs>12){
    hrs=hrs-12;     // 15 - 12 = 3;
   }

    hrs=hrs<10? "0" + hrs : hrs;
    mins=mins<10? "0" + mins : mins;
    sec=sec<10? "0" + sec : sec;

    document.getElementById('hours').innerHTML=hrs;
    document.getElementById('mins').innerHTML=mins;
    document.getElementById('seconds').innerHTML=sec;
}

//Calling Function that will run infinite times!:
setInterval(updateTime,1000);