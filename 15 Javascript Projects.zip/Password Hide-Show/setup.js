const passCODE = document.getElementById('passcode');
const icon = document.getElementById('eyeicon');
const Strength_span= document.querySelector('.strength_area');
const Pass_Strength= document.querySelector('.strength');



passCODE.addEventListener('input',()=>{
    if(passCODE.value.length>0){
        Pass_Strength.style.display="block";
    }else{
        Pass_Strength.style.display='none';
    }

    if(passCODE.value.length<=4)
    {
        Strength_span.innerHTML = " Weak";
        Pass_Strength.style.color="Red"   
    }else if(passCODE.value.length>=5 && passCODE.value.length<=9)
    {
        Strength_span.innerHTML = " Medium";
        Pass_Strength.style.color="orange"
    }else if(passCODE.value.length>=10)
    {
        Strength_span.innerHTML = " Strong";
        Pass_Strength.style.color="#00e700"   
    }

icon.onclick = function()
{
    if(passCODE.type =='password'){
        icon.src="images/eye-open.png";     // 'image will be added'
        passCODE.type='text';
    }else{
        icon.src="images/eye-close.png"     //  'image will be added'
        passCODE.type='password';
    }  
}
})