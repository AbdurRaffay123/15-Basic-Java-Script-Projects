const Center_Number=document.getElementById('number');
let counter=0;

setInterval(()=>{
    if(counter == 75)
  {
        clearInterval();
  }else{
    counter++;
    Center_Number.innerHTML=counter + "%";
 }
},39)