const ShowMoreBtn = document.querySelector(".show_more");
const Search_Form = document.getElementById("search-form");
const Search_Box = document.getElementById("search-box");
const Search_Result = document.getElementById("search_result");
const Show_More = document.querySelector(".show_more");

let keyword = "";
let page = 1;
let accesskey = "Mm-iiDqhmEXq3IrCYnr9k9hZXyqo-3s039ldCdvmuC4";

async function searchImages(){

  keyword = Search_Box.value;
  const url = `https://api.unsplash.com/search/photos?page=${page}&query=${keyword}&client_id=${accesskey}&per_page=15`;



  const response = await fetch(url);
  const data = await response.json();

    if(page===1){
    Search_Result.innerHTML = "";
    }

  let results = data.results;
  results.map((result) => {
    const image = document.createElement("img");
    image.src = result.urls.small;

    const imgLink = document.createElement("a");
    imgLink.href = result.links.html;
    imgLink.target = "_blank";

    imgLink.appendChild(image);
    Search_Result.appendChild(imgLink);
  });

  Show_More.style.display="block";
}

Search_Form.addEventListener("submit", (e) => {
  e.preventDefault();
  page = 1;
  searchImages();
});

Show_More.addEventListener("click", ()=>{
    page++;
    searchImages();
});