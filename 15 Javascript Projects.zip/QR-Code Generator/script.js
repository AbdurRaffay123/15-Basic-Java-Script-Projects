const QR_Code="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=";
const text_Box = document.getElementById("textBox");
const button=document.querySelector(".btn");
const Image_QR=document.querySelector(".ImageQR");
const ImgBox= document.querySelector(".imgBox")


function GenerateQRCode(){
    if(text_Box.value.length > 0)
 {
    Image_QR.src= "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" + text_Box.value;
    Image_QR.style.display="block";

 }else{
    text_Box.classList.add("error");
    setTimeout(()=>
    {
        text_Box.classList.remove("error");
    },1000)
}
}